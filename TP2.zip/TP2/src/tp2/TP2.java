package tp2;

import Controleur.Controleur;
import Modele.Modele;
import Vue.FenetreJeu;

/**
 *
 * @author Audrey et Cloé
 */
public class TP2 {
    /**
     * 
     * @param args 
     */
    public static void main(String[] args) {
        
        Modele modele = new Modele();
        FenetreJeu vue = new FenetreJeu(modele);
        Controleur controleur = new Controleur(vue, modele);
    }
    
}
