package Modele;

import java.util.Observable;

/**
 *
 * @author Cloé et Audrey
 */
public class Modele extends Observable{
    
    int niveauDifficulte = 0;
    int nbVies = 3;
    int points = 0;
    int nbBalles = 0;
    
    /**
     * 
     * @return le niveau de difficulté
     */
    public int getNiveauDifficulte() {
        return niveauDifficulte;
    }
    /**
     * augmente le niveau de difficulté de 1
     */
	public void augmenteDifficulte() {
		niveauDifficulte++;
		setChanged();
		notifyObservers(this);
	}
    /**
     * remet le niveau de difficulté à 0
     */
    public void reset() {
        niveauDifficulte = 0;
    	nbVies = 3;
    	points = 0;
    	setChanged();
    	notifyObservers(this);            
    }
    public void resetVies() {
    	nbVies = 3;
    	setChanged();
    	notifyObservers(this);            
    }
    
    public int getNombreDeVies() {
    	return nbVies;
    }
    
    public void reduireViesHero() {
    	nbVies--;
    	setChanged();
    	notifyObservers(this);
    }
    
    public void ajouterPoints(int points) {
    	this.points += points;
    	setChanged();
    	notifyObservers(this);   
    }
    
    public int getPoints() {
    	return points;
    }
    
    public void ajouterBalles(int nbBalles) {
    	this.nbBalles += nbBalles;
    }
    
    public void reduireBalle() {
    	nbBalles--;
    }
    
    public int getNbBalles() {
    	return nbBalles;
    }
    
}
