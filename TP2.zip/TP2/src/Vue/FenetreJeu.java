package Vue;

import Modele.Modele;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import javax.swing.*;


/**
 *
 * @author Audrey et Cloé
 */
public class FenetreJeu extends JFrame implements Observer {

    int points = 0;
    JPanel pnlInfo = new JPanel(new GridLayout(1, 3));
    JLabel lblPoints = new JLabel("Points: " + points);
    JLabel lblNiveau = new JLabel("Niveau: " + 0);
    JPanel pnlVie = new JPanel();

    private final int LARGEUR = 15;//divisé en 15
    private final int HAUTEUR = 15;
    private final int DIMENSION_TUILE = 32;//nombre de pixels par carré

    private Gazon gazon = new Gazon(LARGEUR, HAUTEUR);
    private int[][] positionRoches = {{0, 0}, {0, 1}, {0, 2}, {0, 3}, {0, 11}, {0, 12},
    {0, 13}, {0, 14}, {1, 0}, {1, 14}, {2, 0}, {2, 14},
    {3, 0}, {3, 14}, {11, 0}, {11, 14}, {12, 0}, {12, 14},
    {13, 0}, {13, 14}, {14, 0}, {14, 1}, {14, 2}, {14, 3},
    {14, 11}, {14, 12}, {14, 13}, {14, 14}};

    int nombreDeCoeurs = 0; 
    private ArrayList<Coeur> coeurs = new ArrayList<>();

    private ArrayList<Roche> roches = new ArrayList<>();

    private int[][] positionBuisson = {{4, 4}, {4, 10}, {10, 4}, {10, 10}};

    private ArrayList<Buisson> buissons = new ArrayList<>();

    private Hero hero = new Hero(LARGEUR * DIMENSION_TUILE / 2, HAUTEUR * DIMENSION_TUILE / 2);//mettre le hero au centre

    private ArrayList<Tentacule> tentacules = new ArrayList<>();

    private ArrayList<Objet> missiles = new ArrayList<>();
    
    private ArrayList<Boost> boosts = new ArrayList<>();
    private ArrayList<Bombe> bombes = new ArrayList<>();
    private ArrayList<BalleBonus> ballesBonus = new ArrayList<>();
    
    private JPanel pnlPrincipal = new JPanel(new BorderLayout());
    private JLayeredPane pnlJeu = new JLayeredPane();
    private final Modele modele;
    private JMenuBar monMenu = new JMenuBar();
    private final JMenu mnuFichier = new JMenu("Fichier");
    private final JMenu mnuAide = new JMenu("?");
    private final JMenuItem mnuNouvellePartie = new JMenuItem("Nouvelle partie");
    private final JMenuItem mnuQuitter = new JMenuItem("Quitter");
    private final JMenuItem mnuSousAide = new JMenuItem("Aide");
    private final JMenuItem mnuAPropos = new JMenuItem("À propos");

    /**
     *
     * @param modele Initialisation des paramètres du jeu
     */
    public FenetreJeu(Modele modele) {

        modele.addObserver(this);

        this.modele = modele;
        modele.addObserver(this);
        setTitle("La Contre-Attaque");

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Dimension dimensionGazon = new Dimension();

        gazon.getSize(dimensionGazon);
        pnlJeu.setPreferredSize(dimensionGazon);

        add(pnlPrincipal);

        initMenu();
        initPlanDeJeu();
        
        nombreDeCoeurs = modele.getNombreDeVies();

        setResizable(false);
        pack();

        this.setVisible(true);
    }

    /**
     *
     * @param o
     * @param o1
     */
    @Override
    public void update(Observable o, Object o1) {
    	SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	while (modele.getNombreDeVies() < nombreDeCoeurs && nombreDeCoeurs > 0) {
            		pnlVie.getComponent(nombreDeCoeurs - 1).setVisible(false);
            		nombreDeCoeurs--;
            	}
            	while (modele.getNombreDeVies() > nombreDeCoeurs) {
            		pnlVie.getComponent(nombreDeCoeurs).setVisible(true);
            		nombreDeCoeurs++;
            	}
            	lblNiveau.setText("Niveau: " + modele.getNiveauDifficulte());
            	lblPoints.setText("Points: " + modele.getPoints());
				if (modele.getNombreDeVies() == 0) {
					finDePartie();				
				}
			}
        });
    }
    
    private void finDePartie() {
		hero.setLocation(LARGEUR * DIMENSION_TUILE / 2, HAUTEUR * DIMENSION_TUILE / 2);
		while (!tentacules.isEmpty()) {
			removeTentacule(tentacules.get(0));
		}
		
		while (!missiles.isEmpty()) {
			removeMissile(missiles.get(0));
		}
		
		while (!boosts.isEmpty()) {
			removeBoost(boosts.get(0));
		}
		
		int dialogBouton = JOptionPane.YES_NO_OPTION;
		String[] options = {"Oui", "Non"};
		int reponse = JOptionPane.showOptionDialog(null,
				"Vous êtes " + "fatigué et vous vous couchez pour un "
						+ "long repos.VOUS ÊTES MOOORRRRRTTTT."
						+ "Voulez-vous rejouer une partie?",
				"Question", dialogBouton, JOptionPane.QUESTION_MESSAGE, null, options, "Non");
		if (reponse == JOptionPane.NO_OPTION) {
			System.exit(0);
		} else if (reponse == JOptionPane.YES_OPTION) {
			modele.reset();
		}	   	
    }

    /**
     * Ajoute les composantes du menu à la barre de menu
     */
    private void initMenu() {
        pnlPrincipal.add(pnlJeu, BorderLayout.CENTER);
        //pnlJeu.add(monMenu);
        monMenu.add(mnuFichier);
        monMenu.add(mnuAide);
        mnuFichier.add(mnuNouvellePartie);
        mnuFichier.addSeparator();
        mnuFichier.add(mnuQuitter);
        mnuAide.add(mnuSousAide);
        mnuAide.addSeparator();
        mnuAide.add(mnuAPropos);
        setJMenuBar(monMenu);
        
        pnlInfo.setPreferredSize(new Dimension(LARGEUR * DIMENSION_TUILE, 30));
        pnlPrincipal.add(pnlInfo, BorderLayout.NORTH);
        pnlInfo.add(lblPoints);
        pnlInfo.add(lblNiveau);
        pnlInfo.add(pnlVie);
    }

    /**
     * Dessine le gazon, les roches et les buisson sur la fenêtre du jeu
     */
    private void initPlanDeJeu() {
        // Ajoute le gazon en arrière plan.
        pnlJeu.add(gazon);

        for (int[] position : positionRoches) {
            Roche roche = new Roche(position[0], position[1]);//ça veut dire quoi déjà??
            roches.add(roche);
            pnlJeu.add(roche, 0);
        }
        for (int[] position : positionBuisson) {
            Buisson buisson = new Buisson(position[0], position[1]);
            buissons.add(buisson);
            pnlJeu.add(buisson, 0);
        }
        for (int i = 0; i < modele.getNombreDeVies(); i++) {
            Coeur coeur = new Coeur();
            coeurs.add(coeur);
            pnlVie.add(new JLabel(coeur));
        }

        pnlJeu.add(hero, 0);
    }

    /**
     * Exécution de chaque composante du menu
     */
    public void ListenersMenus() {
        mnuNouvellePartie.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

            }
        });

        mnuQuitter.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                int dialogBouton = JOptionPane.YES_NO_OPTION;
                int reponse = JOptionPane.showConfirmDialog(null, "Voulez-vous vraiment quitter ce merveilleux jeux?", "Question", dialogBouton);
                if (reponse == JOptionPane.NO_OPTION) {

                } else if (reponse == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });

        mnuSousAide.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                JOptionPane.showMessageDialog(null, "Vous devez battre les "
                        + "tentacules pour avoir le plus de points. Vous pouvez vous déplacer"
                        + " avec les flèche du clavier et tirer avec la barre "
                        + "d'espacement. Vous avez 3 points de vie. Lorsque "
                        + "vous entrez en collision avec un ennemi vous perdez"
                        + " une vie. Lorsque vous tuez un tentacules vous pouvez"
                        + " avoir un bonus.Un bonus attrapé=5pts La partie se termine quand vous mourrez"
                        + " ou quand vous être tanné.");
            }
        });
        mnuAPropos.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                JOptionPane.showMessageDialog(null, "Audrey Lupien et Cloé Lachance créé le 8 décembre");
            }
        });
    }

    /**
     *
     * @return hero
     */
    public Hero getHero() {
        return hero;
    }

    /**
     *
     * @return la liste de roches
     */
    public ArrayList<Roche> getRoches() {
        return roches;
    }

    /**
     *
     * @return la liste de buissons
     */
    public ArrayList<Buisson> getBuissons() {
        return buissons;
    }

    /**
     *
     * @return la liste de tentacules
     */
    public ArrayList<Tentacule> getTentacules() {
        return tentacules;
    }

    /**
     *
     * @return la liste de lasers
     */
    public ArrayList<Objet> getMissiles() {
        return missiles;
    }

    /**
    *
    * @return la liste de boosts
    */
   public ArrayList<Boost> getBoosts() {
       return boosts;
   }
   
   	/**
	 *
	 * @return la liste de bombes
	 */
	public ArrayList<Bombe> getBombes() {
		return bombes;
	}

   	/**
	 *
	 * @return la liste de bonus de balles
	 */
	public ArrayList<BalleBonus> getBallesBonus() {
		return ballesBonus;
	}
	
    /**
     *
     * @return la dimension du jeu
     */
    public Dimension getDimensionJeu() {
        return pnlJeu.getSize();
    }

    public int getPoints() {
        return points;
    }
    
    public void addMissile(Objet missile) {
		synchronized (missiles) {// Emp�che que 2 actions soient effectuées en même temps sur la m�me liste
			missiles.add(missile);
		}	
    	pnlJeu.add(missile, 0);
    }
    
    public void removeMissile(Objet missile) {
		synchronized (missiles) {// Emp�che que 2 actions soient effectu�es en m�me temps sur la m�me liste
			missiles.remove(missile);
		}	
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
		    	pnlJeu.remove(missile);
			}
		});
    }
    
    public void addTentacule(Tentacule tentacule) {
    	synchronized (tentacules) {
			tentacules.add(tentacule);
		}
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
		    	pnlJeu.add(tentacule, 0);
			}
		});
    }
    
    public void removeTentacule(Tentacule tentacule) {
    	synchronized (tentacules) {
			tentacules.remove(tentacule);
		}
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
		    	pnlJeu.remove(tentacule);
			}
		});
    }

    public void addBoost(Boost boost) {
		synchronized (boosts) {// Emp�che que 2 actions soient effectuées en même temps sur la m�me liste
			boosts.add(boost);
		}	
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
		    	pnlJeu.add(boost, 0);
			}
		});
    }
    
    public void removeBoost(Boost boost) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
		    	pnlJeu.remove(boost);
			}
		});
    }

    public void addBombe(Bombe bombe) {
		synchronized (bombes) {// Emp�che que 2 actions soient effectuées en même temps sur la m�me liste
			bombes.add(bombe);
		}	
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
		    	pnlJeu.add(bombe, 0);
			}
		});
    }
    
    public void removeBombe(Bombe bombe) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
		    	pnlJeu.remove(bombe);
			}
		});
    }
    
    public void addBallesBonus(BalleBonus balleBonus) {
		synchronized (ballesBonus) {// Emp�che que 2 actions soient effectuées en même temps sur la m�me liste
			ballesBonus.add(balleBonus);
		}	
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
		    	pnlJeu.add(balleBonus, 0);
			}
		});
    }
    
    public void removeBallesBonus(BalleBonus balleBonus) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
		    	pnlJeu.remove(balleBonus);
			}
		});
    }
}
