package Vue;

import java.awt.Toolkit;

/**
 *
 * @author Audrey et Cloé
 */
public class TentaculeBleu extends Tentacule {
    /**
     * Dessine la bonne image selon la direction du tentacule bleu
     */
    public TentaculeBleu() {
    	super();
        image[Direction.SUD.ordinal()] = Toolkit.getDefaultToolkit().getImage("images/bleufront.gif");
        image[Direction.NORD.ordinal()] = Toolkit.getDefaultToolkit().getImage("images/bleuback.gif");
        image[Direction.EST.ordinal()] = image[Direction.SUD.ordinal()];
        image[Direction.OUEST.ordinal()] = image[Direction.SUD.ordinal()];
    }
    /**
     * 
     * @return le nombre de vies initiales
     */
    @Override
    public int getViesInitiales() {
        return 1;
    }
    /**
     * 
     * @return le nombre de points
     */
    @Override
    public int getPoints() {
        return 2;
    }
    /**
     * 
     * @return la vitesse
     */
    @Override
    public int getVitesse() {
        return 2;
    }
}
