package Vue;

import java.awt.*;

/**
 *
 * @author Audrey et Cloé
 */
public class Roche extends Objet {

    Image image = Toolkit.getDefaultToolkit().getImage("images/roche1.gif");//32x32
    /**
     * 
     * @param g 
     */
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
            g.drawImage(image, 0, 0, this);
    }
    /**
     * 
     * @param x
     * @param y 
     * permet de transformer la position en termes de 15 cases à partir des pixels
     */
    public Roche(int x, int y) {
        setSize(32,32);
        setLocation(x*32, y*32);
    }

}
