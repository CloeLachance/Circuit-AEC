package Vue;

import java.awt.Toolkit;

/**
 *
 * @author Cloé et Audrey
 */
public class TentaculeMauve extends Tentacule {
    /**
     * Dessine la bonne image selon la direction du tentacule mauve
     */
    public TentaculeMauve() {
    	super();
        image[Direction.SUD.ordinal()] = Toolkit.getDefaultToolkit().getImage("images/purplefront.gif");
        image[Direction.NORD.ordinal()] = Toolkit.getDefaultToolkit().getImage("images/purpleback.gif");
        image[Direction.EST.ordinal()] = image[Direction.SUD.ordinal()];
        image[Direction.OUEST.ordinal()] = image[Direction.SUD.ordinal()];
    }
    /**
     * 
     * @return le nombre de vies initiales
     */
    @Override
    public int getViesInitiales() {
        return 2;
    }
    /**
     * 
     * @return le nombre de points
     */
    @Override
    public int getPoints() {
        return 3;
    }
    /**
     * 
     * @return la vitesse
     */
    @Override
    public int getVitesse() {
        return 1;
    }
}
