package Vue;

import java.awt.*;

/**
 *
 * @author Audrey et Cloé
 */
public class TentaculeVert extends Tentacule {
    /**
     * Dessine la bonne image selon la direction du tentacule vert
     */
    public TentaculeVert() {
    	super();
        image[Direction.SUD.ordinal()] = Toolkit.getDefaultToolkit().getImage("images/greenfront.gif");
        image[Direction.NORD.ordinal()] = Toolkit.getDefaultToolkit().getImage("images/greenback.gif");
        image[Direction.EST.ordinal()] = image[Direction.SUD.ordinal()];
        image[Direction.OUEST.ordinal()] = image[Direction.SUD.ordinal()];
    }
    /**
     * 
     * @return le nombre de vie
     */
    @Override
    public int getViesInitiales() {
        return 1;
    }
    /**
     * 
     * @return le nombre de points
     */
    @Override
    public int getPoints() {
        return 1;
    }
    /**
     * 
     * @return la vitesse
     */
    @Override
    public int getVitesse() {
        return 1;
    }
}
