package Vue;

import java.awt.*;

/**
 *
 * @author Cloé et Audrey
 */
public class Laser extends Objet {
    private final int LARGEUR = 5;
    private final int HAUTEUR = 15;
    
    Direction direction;
    /**
     * 
     * @param x
     * @param y
     * @param direction 
     */
    public Laser(int x, int y, Direction direction) {
        if (direction == Direction.NORD || direction == Direction.SUD) {
            setSize(LARGEUR, HAUTEUR);
        } else if (direction == Direction.EST || direction == Direction.OUEST) {
            setSize(HAUTEUR, LARGEUR);
        } 
        this.direction = direction;
        setLocation(x, y);
    }
    /**
     * 
     * @param g 
     * Dessine un rectangke rouge
     */
     @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.RED);
        g.fillRect(0, 0, getWidth(), getHeight());  
    }
    /**
     * selon la direction du hero, le laser bouge dans la bonne direction
     */
    public void bouge() {
          Rectangle pos = getBounds();
        if (null != direction) 
            switch (direction) {
            case NORD:
                pos.translate(0, -5);
                break;
            case SUD:
                pos.translate(0, 5);
                break;
            case EST:
                pos.translate(5, 0);
                break;
            case OUEST:
                pos.translate(-5, 0);
                break;
            default:
                break;
        }
        
        setBounds(pos);      
    }
}
