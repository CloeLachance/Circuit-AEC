package Vue;

import javax.swing.JComponent;

/**
 *
 * @author Audrey et Cloé
 */
public abstract class Objet extends JComponent{
    /**
     * un énum des 4 points cardinaux
     */
    public enum Direction {
        NORD,
        SUD,
        EST,
        OUEST,
    	NORDEST,
    	NORDOUEST,
    	SUDEST,
    	SUDOUEST;
    }
    
    public int getPoints() {
    	return 0;
    }
    
    public void bouge() {
    }
}
