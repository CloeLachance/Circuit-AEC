package Vue;

import java.awt.*;
import java.util.ArrayList;

/**
 *
 * @author Cloé et Audrey
 */
public abstract class Tentacule extends Objet {
       
    private Direction direction = Direction.SUD;
    
    protected Image image[] = new Image[4];
    
    private int nbVies;
    
    private static int LARGEUR = 35;
    private static int HAUTEUR = 43;
    
    /**
     * 
     */
    public Tentacule() {
        setSize(LARGEUR, HAUTEUR);
        nbVies = getViesInitiales();
    }
    
    public static Dimension getDimension() {
    	return new Dimension(LARGEUR, HAUTEUR);
    }
    
    /**
     * 
     * @param g 
     */ 
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
            g.drawImage(image[direction.ordinal()], 0, 0, this);
    }
    /**
     * 
     * @param direction --> Nord, sud, est, ouest
     * @param obstacles --> la liste des obstacles
     */
    public void bouge(Direction direction, ArrayList<Objet> obstacles) {
        this.direction = direction;
        Rectangle pos = getBounds();
        if (direction == Direction.NORD) {
            pos.translate(0, -getVitesse());
        } else if (direction == Direction.SUD) {
            pos.translate(0, getVitesse());
        } else if (direction == Direction.EST) {
            pos.translate(getVitesse(), 0);
        } else if (direction == Direction.OUEST) {
            pos.translate(-getVitesse(), 0);
        }
        
        for (Objet obstacle : obstacles) {
            if (obstacle.getBounds().intersects(pos)) {
                return;
            }
        } 
        setBounds(pos);
    }
    /**
     * réduit de 1 le nbr de vie d'un tentacule
     */
    public void reduireVie() {
        nbVies--;
    }
    /**
     * 
     * @return true si le tentacule est mort
     *         false si le tentacule est encore en vie
     */
    public boolean estMort() {
        if (nbVies <= 0) {
            return true;
        } else {
            return false;
        }
    }
    /**
     * 
     * @return le nombre de vies
     */
    public abstract int getViesInitiales();

    /**
     * 
     * @return la vitesse
     */
    public abstract int getVitesse();
}
