/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

/**
 *
 * @author clachance
 */
public class BalleBonus extends Objet {
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.BLACK);
        g.fillOval(10, 5, 10, 10);
        g.fillOval(0, 15, 10, 10); 
        g.fillOval(20, 15, 10, 10); 
    }

    public BalleBonus(int x, int y) {
        setSize(30,30);
        setLocation(x, y);
    }
    
    public int getPoints() {
    	return 5;
    }
}
