package Vue;

import java.awt.*;

/**
 *
 * @author Cloé et Audrey
 */
public class Gazon extends Objet {

    Image imageGazon = Toolkit.getDefaultToolkit().getImage("images/floor1.gif");//32x32
    /**
     * 
     * @param g
     * Dessine un carré de gazon sur toute la dimension du jeu
     */
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (int i = 0; i < 480; i += 32) {
            for (int j = 0; j < 480; j += 32) {
                g.drawImage(imageGazon, i, j, this);
            }
        }
    }

    public Gazon(int largeur, int hauteur) {
        setSize(32*largeur,32*hauteur);
    }

}
