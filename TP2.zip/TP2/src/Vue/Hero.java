package Vue;

import java.awt.*;
import java.util.ArrayList;

/**
 *
 * @author Audrey et Cloé
 */
public class Hero extends Objet {

    Direction direction = Direction.SUD;

    Image image[] = new Image[4];

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image[direction.ordinal()], 0, 0, this);
    }

    /**
     *
     * @param x
     * @param y
     */
    public Hero(int x, int y) {
        image[Direction.SUD.ordinal()] = Toolkit.getDefaultToolkit().getImage("images/herofront.gif");
        image[Direction.NORD.ordinal()] = Toolkit.getDefaultToolkit().getImage("images/heroback.gif");
        image[Direction.EST.ordinal()] = Toolkit.getDefaultToolkit().getImage("images/herodroite.gif");
        image[Direction.OUEST.ordinal()] = Toolkit.getDefaultToolkit().getImage("images/herogauche.gif");
        setSize(22, 51);
        setLocation(x - 11, y - 25);
    }

    /**
     *
     * @param direction --> Nord, sud, est ou ouest
     * @param obstacles --> la liste d'objets
     */
    public void bouge(Direction direction, ArrayList<Objet> obstacles) {
        this.direction = direction;
        Rectangle pos = getBounds();
        if (null != direction) {
            switch (direction) {
                case NORD:
                    pos.translate(0, -2);
                    break;
                case SUD:
                    pos.translate(0, 2);
                    break;
                case EST:
                    pos.translate(2, 0);
                    break;
                case OUEST:
                    pos.translate(-2, 0);
                    break;
                default:
                    break;
            }
        }

        for (Objet obstacle : obstacles) {
            if (obstacle.getBounds().intersects(pos)) {
                return;
            }
        }

        setBounds(pos);
    }

    /**
     *
     * @return la direction courante du hero
     */
    public Direction getDirection() {
        return direction;
    }
}
