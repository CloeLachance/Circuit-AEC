package Vue;

import java.awt.*;

/**
 *
 * @author Cloé et Audrey
 */
public class Balle extends Objet {
    private final int LARGEUR = 5;
    private final int HAUTEUR = 5;
    
    Direction direction;
    /**
     * 
     * @param x
     * @param y
     * @param direction 
     */
    public Balle(int x, int y, Direction direction) {
		setSize(LARGEUR, HAUTEUR);
		this.direction = direction;
		setLocation(x, y);
    }
    /**
     * 
     * @param g 
     * Dessine un rectangke rouge
     */
     @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.BLACK);
        g.fillOval(0, 0, getWidth(), getHeight());  
    }
    /**
     * selon la direction du hero, le laser bouge dans la bonne direction
     */
    public void bouge() {
          Rectangle pos = getBounds();
        if (null != direction) 
            switch (direction) {
            case NORD:
                pos.translate(0, -5);
                break;
            case SUD:
                pos.translate(0, 5);
                break;
            case EST:
                pos.translate(5, 0);
                break;
            case OUEST:
                pos.translate(-5, 0);
                break;
            case NORDEST:
                pos.translate(5, -5);
                break;
            case NORDOUEST:
                pos.translate(-5, -5);
                break;
            case SUDEST:
                pos.translate(5, 5);
                break;
            case SUDOUEST:
                pos.translate(-5, 5);
                break;                
            default:
                break;
        }
        
        setBounds(pos);      
    }
}
