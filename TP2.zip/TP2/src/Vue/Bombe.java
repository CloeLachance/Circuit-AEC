/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

/**
 *
 * @author clachance
 */
public class Bombe extends Objet {
    Image image = Toolkit.getDefaultToolkit().getImage("images/Bombe.gif");

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
            g.drawImage(image, 0, 0, this);
    }

    public Bombe(int x, int y) {
        setSize(30,25);
        setLocation(x, y);
    }
    
    public int getPoints() {
    	return 5;
    }
}
