package Controleur;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.SwingUtilities;
import javax.swing.Timer;

import Modele.Modele;
import Vue.Balle;
import Vue.BalleBonus;
import Vue.Bombe;
import Vue.Boost;
import Vue.FenetreJeu;
import Vue.Hero;
import Vue.Laser;
import Vue.Objet;
import Vue.Objet.Direction;
import Vue.Tentacule;
import Vue.TentaculeBleu;
import Vue.TentaculeMauve;
import Vue.TentaculeVert;

/**
 *
 * @author Cloé et Audrey
 */
public class Controleur {

	private FenetreJeu vue;
	private Modele modele;
	private Hero hero;
	private HeroThread heroThread = new HeroThread();
	private TentaculesThread tentaculesThread = new TentaculesThread();
	private MissilesThread missilesThread = new MissilesThread();
	private ArrayList<Integer> listeKeyCodes = new ArrayList<>();
	private ArrayList<Objet> obstacles = new ArrayList<>();
	Set<Tentacule> tentaculesMorts = new HashSet<>();

	private long tempsAjoutDeTentacules = 0;
	private long tempsAjoutDeDifficute = 0;

	private int pourcentageVert = 100;
	private int pourcentageBleu = 0;
	private int pourcentageMauve = 0;
	int nbDeTentacules = 1;

	private Timer timer;

	/**
	 *
	 * @param vue
	 * @param modele
	 */
	public Controleur(FenetreJeu vue, Modele modele) {
		this.vue = vue;
		this.modele = modele;
		heroThread.start();
		missilesThread.start();
		tentaculesThread.start();
		hero = vue.getHero();
		obstacles.addAll(vue.getBuissons());
		obstacles.addAll(vue.getRoches());
		initActions();
		tempsAjoutDeDifficute = System.currentTimeMillis();

		timer = new Timer(9000, new ActionListener() {
			/**
			 *
			 * @param e
			 *            Aux 9 secondes le niveau de difficulté augmente
			 */
			@Override
			public void actionPerformed(ActionEvent e) {
				modele.augmenteDifficulte();
				if (modele.getNiveauDifficulte() == 1) {
					pourcentageVert = 70;
					pourcentageBleu = 30;
					pourcentageMauve = 0;
				} else if (modele.getNiveauDifficulte() == 2) {
					pourcentageVert = 50;
					pourcentageBleu = 40;
					pourcentageMauve = 10;
				} else if (modele.getNiveauDifficulte() == 3) {
					pourcentageVert = 30;
					pourcentageBleu = 50;
					pourcentageMauve = 20;
				} else if (modele.getNiveauDifficulte() == 4) {
					pourcentageVert = 20;
					pourcentageBleu = 40;
					pourcentageMauve = 40;
					nbDeTentacules++;
				} else if (modele.getNiveauDifficulte() == 5) {
					pourcentageVert = 10;
					pourcentageBleu = 30;
					pourcentageMauve = 60;
				} else if (modele.getNiveauDifficulte() == 6) {
					pourcentageVert = 5;
					pourcentageBleu = 20;
					pourcentageMauve = 75;
				} else if (modele.getNiveauDifficulte() == 7) {
					pourcentageVert = 5;
					pourcentageBleu = 10;
					pourcentageMauve = 85;
				} else {
					if (modele.getNiveauDifficulte() % 4 == 0) {
						nbDeTentacules++;
					}
				}
			}
		});
		timer.start();

	}

	/**
	 * code donné pour les touches actionnées simultanément
	 */
	private void initActions() {
		vue.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (!listeKeyCodes.contains(e.getKeyCode())) {
					listeKeyCodes.add(e.getKeyCode());
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// On enlève l’objet Integer, on ne veut pas
				// enlever une position dans l’ArrayList
				listeKeyCodes.remove(new Integer(e.getKeyCode()));
			}
		});
	}

	/**
	 * thread qui s'occupe du heros
	 */
	public class HeroThread extends Thread {

		public HeroThread() {
		}

		/**
		 * Selon la flèche pesée, le personnage bouge dans la bonne direction Détecte
		 * si un obstacle lui bloque le chemin
		 */
		@Override
		public void run() {
			while (true) {
				Objet.Direction direction = null;
				if (listeKeyCodes.contains(KeyEvent.VK_LEFT)) {
					if (hero.getLocation().x > 0) {
						direction = Objet.Direction.OUEST;
					}
				}
				if (listeKeyCodes.contains(KeyEvent.VK_RIGHT)) {
					if (hero.getLocation().x + hero.getWidth() < vue.getDimensionJeu().getWidth()) {
						direction = Objet.Direction.EST;
					}
				}
				if (listeKeyCodes.contains(KeyEvent.VK_UP)) {
					if (hero.getLocation().y > 0) {
						direction = Objet.Direction.NORD;
					}
				}
				if (listeKeyCodes.contains(KeyEvent.VK_DOWN)) {
					if (hero.getLocation().y + hero.getHeight() < vue.getDimensionJeu().getHeight()) {
						direction = Objet.Direction.SUD;
					}
				}
				if (direction != null) {
					hero.bouge(direction, obstacles);
				}
				
				// Utilise un iterateur afin de pouvoir l'enlever du ArrayList de boost pendant l'itération.
				Iterator<Boost> iterateur = vue.getBoosts().iterator();
				while (iterateur.hasNext()) {
					Boost boost = iterateur.next();
					if (hero.getBounds().intersects(boost.getBounds())) {
						iterateur.remove();
						vue.removeBoost(boost);
						modele.resetVies();
						modele.ajouterPoints(boost.getPoints());
					}
				}
				
				Iterator<BalleBonus> itrBalleBonus = vue.getBallesBonus().iterator();
				while (itrBalleBonus.hasNext()) {
					BalleBonus bonus = itrBalleBonus.next();
					if (hero.getBounds().intersects(bonus.getBounds())) {
						itrBalleBonus.remove();
						vue.removeBallesBonus(bonus);
						modele.ajouterPoints(bonus.getPoints());
						modele.ajouterBalles(5);
					}
				}
				
				// Utilise un iterateur afin de pouvoir l'enlever du ArrayList de boost pendant l'itération.
				Iterator<Bombe> itrBombe = vue.getBombes().iterator();		
				while (itrBombe.hasNext()) {
					Bombe bombe = itrBombe.next();
					if (hero.getBounds().intersects(bombe.getBounds())) {
						itrBombe.remove();
						vue.removeBombe(bombe);
						ArrayList<Tentacule> tentacules = vue.getTentacules();
						synchronized (tentacules) {
							while (!tentacules.isEmpty()) {
								vue.removeTentacule(tentacules.get(0));
							}
						}
						modele.ajouterPoints(bombe.getPoints());
					}
				}

				try {
					Thread.sleep(8);
				} catch (InterruptedException ex) {
				}
			}

		}

	}

	/**
	 * Thread qui s'occupe des missiles
	 */
	public class MissilesThread extends Thread {

		public MissilesThread() {
		}

		/**
		 * Lorsque la barre d'espace est pesée, un laser est lancé Si un laser touche
		 * un obstacle, il est effacée Si un laser touche un tentacule, il perd une vie et/ou le tentacule
		 * disparait
		 */
		@Override
		public void run() {
			while (true) {
				if (listeKeyCodes.contains(KeyEvent.VK_SPACE)) {
					if (modele.getNbBalles() <= 0) {
						Laser laser = new Laser(hero.getX() + hero.getWidth() / 2, hero.getY() + hero.getHeight() / 2,
								hero.getDirection());
						vue.addMissile(laser);
					} else {
						for (int i = 0; i < 3; i++) {
							Direction direction = hero.getDirection();
							if (i == 1) {
								if (hero.getDirection() == Direction.NORD) {
									direction = Direction.NORDOUEST;
								} else if (hero.getDirection() == Direction.SUD) {
									direction = Direction.SUDOUEST;
								} else if (hero.getDirection() == Direction.EST) {
									direction = Direction.NORDEST;
								}  else if (hero.getDirection() == Direction.OUEST) {
									direction = Direction.NORDOUEST;
								}
							}  else if (i == 2) {
								if (hero.getDirection() == Direction.NORD) {
									direction = Direction.NORDEST;
								} else if (hero.getDirection() == Direction.SUD) {
									direction = Direction.SUDEST;
								} else if (hero.getDirection() == Direction.EST) {
									direction = Direction.SUDEST;
								}  else if (hero.getDirection() == Direction.OUEST) {
									direction = Direction.SUDOUEST;
								}
							} 
							
							Balle balle= new Balle(hero.getX() + hero.getWidth() / 2, hero.getY() + hero.getHeight() / 2,
									direction);
							vue.addMissile(balle);
						}
						modele.reduireBalle();
					}
					listeKeyCodes.remove((Integer) KeyEvent.VK_SPACE);
				}

				ArrayList<Objet> lasersPerdus = new ArrayList<>();
				synchronized (vue.getMissiles()) {
					for (Objet missile : vue.getMissiles()) {
						missile.bouge();
						if (missile.getX() + missile.getWidth() < 0 || missile.getX() > vue.getDimensionJeu().getWidth()
								|| missile.getY() + missile.getHeight() < 0
								|| missile.getY() > vue.getDimensionJeu().getHeight()) {
							lasersPerdus.add(missile);
						}

						for (Objet obstacle : obstacles) {
							if (missile.getBounds().intersects(obstacle.getBounds())) {
								lasersPerdus.add(missile);
							}
						}

						synchronized (vue.getTentacules()) {
							for (Tentacule tentacule : vue.getTentacules()) {
								if (missile.getBounds().intersects(tentacule.getBounds())) {
									lasersPerdus.add(missile);
									tentacule.reduireVie();
									modele.ajouterPoints(tentacule.getPoints());
									if (tentacule.estMort()) {
										tentaculesMorts.add(tentacule);
										Random random = new Random();
										if (random.nextInt(20) == 1) {
											Boost boost = new Boost(tentacule.getX(), tentacule.getY());
											vue.addBoost(boost);
										} else if (random.nextInt(10) == 1) {
											Bombe bombe = new Bombe(tentacule.getX(), tentacule.getY());
											vue.addBombe(bombe);
										} else if (random.nextInt(2) == 1) {
											BalleBonus bonus = new BalleBonus(tentacule.getX(), tentacule.getY());
											vue.addBallesBonus(bonus);
										}
									}
								}
							}
						}
					}
				}
				
				for (Objet laserPerdu : lasersPerdus) {
					vue.removeMissile(laserPerdu);
				}

				synchronized (vue.getTentacules()) {
					for (Tentacule tentacule : vue.getTentacules()) {
						if (hero.getBounds().intersects(tentacule.getBounds())) {
							modele.getNombreDeVies();
							System.out.println(modele.getNombreDeVies());
							modele.reduireViesHero();

							if (modele.getNombreDeVies() == 0) {
								finDePartie();
							}
							tentaculesMorts.add(tentacule);
						}
					}
				}

				for (Tentacule mort : tentaculesMorts) {
					SwingUtilities.invokeLater(new Runnable() {
						@Override
						public void run() {
							vue.removeTentacule(mort);
						}
					});
				}

				vue.repaint();// important!! sinon, le dessin bogue

				try {
					Thread.sleep(8);
				} catch (InterruptedException ex) {
					Logger.getLogger(FenetreJeu.class.getName()).log(Level.SEVERE, null, ex);
				}
			}
		}
	}

	/**
     * Selon le random pourcentage, le pourcentage du niveau de difficulté, créé
     * le bon tentacule Selon le random cote, le tentacule sort d'un coté ou
     * l'autre du jeu
     */
    private void ajouterTentacules(int cote, int nbDeTentacules) {
    	if (modele.getNombreDeVies() == 0) {
    		return;
    	}
    	
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				Random random = new Random();

				Dimension dimensionJeu = vue.getDimensionJeu();
				
				int xInitial = (int)(dimensionJeu.width - Tentacule.getDimension().getWidth()*nbDeTentacules)/2;
				int yInitial = (int)(dimensionJeu.height - Tentacule.getDimension().getHeight()*nbDeTentacules)/2;
				for (int i = 0; i < nbDeTentacules; i++) {
					int x = 0;
					int y = 0;
					int pourcentage = random.nextInt(100);
					Tentacule tentacule;
					if (pourcentage < pourcentageVert) {
						tentacule = new TentaculeVert();
					} else if (pourcentage < pourcentageVert + pourcentageBleu) {
						tentacule = new TentaculeBleu();
					} else {
						tentacule = new TentaculeMauve();
					}
					
					switch (cote) {
					case 0:
						// Nord
						x = xInitial + i*tentacule.getWidth();
						y = 0;
						break;
					case 1:
						// Sud
						x = xInitial + i*tentacule.getWidth();;
						y = (int) dimensionJeu.getHeight() - tentacule.getHeight();
						break;
					case 2:
						// Est
						x = (int) dimensionJeu.getWidth() - tentacule.getWidth();
						y = yInitial + i*tentacule.getHeight();
						break;
					case 3:
						// Ouest
						x = 0;
						y = yInitial + i*tentacule.getHeight();
						break;
					default:
						break;
					}
					tentacule.setLocation(x, y);

					vue.addTentacule(tentacule);					
				}
			}
		});
	}

	/**
	 * Thread qui s'occupe des tentacules
	 */
	public class TentaculesThread extends Thread {

		public TentaculesThread() {
		}

		/**
		 * À toutes les 2 secondes, un nouveau tentacule apparait Selon la position en
		 * x et y du heros, le tentacule tente de le rejoindre Les tentacules évitent
		 * les obstacles comme le heros
		 */
		@Override
		public void run() {
			while (true) {
				long tempsCourrant = System.currentTimeMillis();
				if (tempsCourrant - tempsAjoutDeTentacules > 2000) {
					Random random = new Random();
					int[] tentaculesParCote = {0,0,0,0};
					for (int i = 0; i < nbDeTentacules; i++) {
						int cote = random.nextInt(4);
						// Augmente le nombre de tentacules pour le côté tiré au hasard.
						tentaculesParCote[cote]++;
					}

					// Pour chaque côté ajouter le nombre de tentacules tiré au hasard.
					for (int i = 0; i < 4; i++) {
						if (tentaculesParCote[i] > 0) {
							ajouterTentacules(i, tentaculesParCote[i]);
						}
					}
					
					tempsAjoutDeTentacules = tempsCourrant;
				}

				Tentacule.Direction direction = null;
				ArrayList<Tentacule> tentacules = vue.getTentacules();
				synchronized (tentacules) {
					for (Tentacule tentacule : tentacules) {
						if (tentacule.getX() + tentacule.getWidth() <= hero.getX()) {
							direction = Tentacule.Direction.EST;
						} else if (tentacule.getX() >= hero.getX() + hero.getWidth()) {
							direction = Tentacule.Direction.OUEST;
						}
						if (direction != null) {
							tentacule.bouge(direction, obstacles);
							direction = null;

						}

						if (tentacule.getY() + tentacule.getHeight() <= hero.getY()) {
							direction = Tentacule.Direction.SUD;
						} else if (tentacule.getY() >= hero.getY() + hero.getHeight()) {
							direction = Tentacule.Direction.NORD;
						}
						if (direction != null) {
							tentacule.bouge(direction, obstacles);
							direction = null;
						}
					}
				}

				try {
					Thread.sleep(20);
				} catch (InterruptedException ex) {
				}
			}
		}
	}

	void finDePartie() {
		listeKeyCodes.clear();
	}
}
